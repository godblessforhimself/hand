from PIL import Image
from time import sleep
dr='C:/Users/Tony/Desktop/图片'
img=dr+'/zimu.jpg'
names=['a','b','c','d','e','f','g','h','i','j','k','l','m','n','o','p','q','r','s','t','u','v','w','x','y','z','zh','ch','sh','ng']
if __name__=='__main__':
    im=Image.open(img)
    start=(31,20)
    end=(136,140)
    dx=142-31
    dy=141-20
    xn=5
    yn=6
    index=0
    for j in range(yn):
        for i in range(xn):
            box=(start[0]+i*dx,start[1]+j*dy,end[0]+i*dx,end[1]+j*dy)
            print(box)
            pic=im.crop(box)
            pic.save(names[index]+'.jpg')
            index+=1
